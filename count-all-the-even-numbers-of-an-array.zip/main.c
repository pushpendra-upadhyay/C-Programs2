#include<stdio.h>
int main()
{
    int size,i,count=0;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements %d: ",i+1);
        scanf("%d",&a[i]);
        if(a[i]%2==0)
        count++;
    }
    printf("Even numbers are: ");
    for(i=0;i<size;i++)
    {
        if(a[i]%2==0)
        printf("%d ",a[i]);
    }
    printf("\nno. of even numbers are: %d",count);
    return 0;
}