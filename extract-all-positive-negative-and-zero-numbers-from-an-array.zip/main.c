#include<stdio.h>
int main()
{
    int size,i,pos,neg,zero;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("Positive numbers are: ");
    for(i=0;i<size;i++)
    {
        if(a[i]>0)
        printf("%d ",a[i]);
    }
    printf("\nNegative numbers are: ");
    for(i=0;i<size;i++)
    {
        if(a[i]<0)
        printf("%d ",a[i]);
    }
    printf("\nZeros are: ");
    for(i=0;i<size;i++)
    {
        if(a[i]==0)
        printf("%d ",a[i]);
    }
    return 0;
}


