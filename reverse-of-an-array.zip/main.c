#include<stdio.h>
int main()
{
    int size,i;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements in this array: ");
        scanf("%d",&a[i]);
    }
    printf("The array is: ");
    for(i=0;i<size;i++)
    {
        printf(" %d",a[i]);
    }
    printf("\nReversed array is: ");
    for(i=size-1;i>=0;i--)
    {
        printf(" %d",a[i]);
    }
    return 0;
}
