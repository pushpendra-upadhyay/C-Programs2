#include<stdio.h>
float si(float a,float b,float c)
{
    float s_i;
    s_i=(a*b*c)/100;
    printf("The simple intrest is: %0.2f",s_i);
}
void main()
{
    float prin,rate,tim;
    printf("Enter the principle: ");
    scanf("%f",&prin);
    printf("Enter the rate: ");
    scanf("%f",&rate);
    printf("Enter the tim: ");
    scanf("%f",&tim);
    si(prin,rate,tim);
}
