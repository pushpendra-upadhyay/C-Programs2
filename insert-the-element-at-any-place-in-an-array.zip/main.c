#include<stdio.h>
int main()
{
    int size,i,pos,value;
    printf("Enter the size of array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("The array is: ");
    for(i=0;i<size;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\nEnter the pos at which you want to insert the element: ");
    scanf("%d",&pos);
    printf("\nEnter the value that you  want to insert: ");
    scanf("%d",&value);
    for(i=size-1;i>=pos-1;i--)
    {
        a[i+1]=a[i];
    }
    a[pos-1]=value;
    printf("The updated array is: ");
    for(i=0;i<=size;i++)
    {
        printf(" %d",a[i]);
    }
    return 0;
}
