#include<stdio.h>
float avrg(float sum, float students)
{
    float average,i,size,marks;
    for(i=0;i<=size;i++)
    {
        printf("Enter the size: ");
        scanf("%f",&size);
    }
    
    
}