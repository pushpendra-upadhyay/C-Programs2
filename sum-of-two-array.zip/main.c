#include<stdio.h>
int main()
{
    int size,i;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size],b[size],c[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements in first array: ");
        scanf("%d",&a[i]);
    }
    for(i=0;i<size;i++)
    {
        printf("Enter the elements in second array: ");
        scanf("%d",&b[i]);
    }
    for(i=0;i<size;i++)
    {
        c[i]=a[i]+b[i];
    }
    printf("sum of a[i] and b[i]: ");
    for(i=0;i<size;i++)
    {
        printf(" %d",c[i]);
    }
    return 0;
}
