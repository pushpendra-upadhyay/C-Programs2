#include<stdio.h>
int main()
{
    int size,i,value;
    printf("Enter the size of this array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("The array is: ");
    for(i=0;i<size;i++)
    {
        printf(" %d",a[i]);
    }
    printf("\nEnter the value that you want to add in this array: ");
    scanf("%d",&value);
    a[size]=value;
    for(i=0;i<=size;i++)
    {
        printf(" %d",a[i]);
    }
    return 0;
}