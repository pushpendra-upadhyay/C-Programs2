#include<stdio.h>
int main()
{
    int size,i;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("The array is: ");
    for(i=0;i<size;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\nThe updated array is: ");
    for(i=0;i<size-1;i++)
    {
        printf("%d ",a[i]);
    }
    return 0;
}
