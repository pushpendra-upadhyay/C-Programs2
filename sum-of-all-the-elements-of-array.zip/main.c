#include <stdio.h>
int main ()
{
  int size, i, sum = 0;
  printf ("Enter the size of the array: ");
  scanf ("%d", &size);
  int a[size];
  for (i = 0; i < size; i++)
    {
      printf ("Enter the elements of the array %d: ",i+1);
      scanf ("%d", &a[i]);
      sum += a[i];
    }
  printf ("The array is: ");
  for (i = 0; i < size; i++)
    {
      printf (" %d", a[i]);
    }
  printf ("\nsum of all the elements of this array: %d", sum);

  return 0;
}

