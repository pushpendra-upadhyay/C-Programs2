#include <stdio.h>
int main()
{
    int size,i,count=0;
    printf("Enter size of the array : ");
    scanf("%d", &size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements %d: ",i+1);
        scanf("%d",&a[i]);
        if(a[i]<0)
        count++;
    }
    printf("\nAll negative elements in array are : ");
    for(i=0;i<size;i++)
    {
        if(a[i]<0)
        printf("%d ",a[i]);
    }
    printf("\nnumber of negative elements: %d",count);
    return 0;
}
