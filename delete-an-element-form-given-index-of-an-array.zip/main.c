#include <stdio.h>
int main ()
{
    int size,i,index;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("The array is: ");
    for(i=0;i<size;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\nEnter the index to be deleted: ");
    scanf("%d",&index);
    for(i=index;i<size;i++)
    {
        a[i]=a[i+1];
    }
      printf("The updated array is: ");
    for(i=0;i<size-1;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
    return 0;
}
