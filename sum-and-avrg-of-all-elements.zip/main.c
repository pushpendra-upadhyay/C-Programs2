#include<stdio.h>
int main ()
{
    int size,i; float sum,avrg;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements in this array: ");
        scanf("%d",&a[i]);
        sum+=a[i];
    }
    avrg=sum/size;
    printf("The array is: ");
    for(i=0;i<size;i++)
    {
        printf(" %d",a[i]);
    } 
    printf("\n");
    printf("sum of all the elements of this array: %0.02f ",sum);
    printf("\navrg of all the elements of this array: %0.02f ",avrg);
    return 0;
}