#include<stdio.h>
int main()
{
    int size,i,even=0,odd=0;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements %d: ",i+1);
        scanf("%d",&a[i]);
        if(a[i]%2==0)
        even++;
        if(a[i]%2!=0)
        odd++;
    }
    printf("Even numbers are: ");
    for(i=0;i<size;i++)
    {
        if(a[i]%2==0)
        printf("%d ",a[i]);
    }
    printf("\nno. of even numbers are: %d",even);
    printf("\nOdd numbers are: ");
    for(i=0;i<size;i++)
    {
        if(a[i]%2!=0)
        printf("%d ",a[i]);
    }
    printf("\nno. of odd numbers are: %d",odd);
    return 0;
}


