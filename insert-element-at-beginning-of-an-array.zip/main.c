#include<stdio.h>
int main()
{
    int size,i,value;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements %d : ",i+1);
        scanf("%d",&a[i]);
    }
    printf("The array created is: ");
    for(i=0;i<size;i++)
    {
        printf(" %d",a[i]);
    }
    printf("\nEnter the value you want to be insert: ");
    scanf("%d",&value);
    for(i=size-1;i>=0;i--)
    {
        a[i+1]=a[i];
    }
    a[0]=value;
    printf("The updated array is: ");
    for(i=0;i<=size;i++)
    {
     printf(" %d",a[i]);   
    }
    return 0;
}

