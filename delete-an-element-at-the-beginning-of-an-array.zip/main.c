#include<stdio.h>
int main()
{
    int size,i;
    printf("Enter the size the of an array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("The array is: ");
    for(i=0;i<size;i++)
    {
        printf("%d ",a[i]);
    }
    for(i=0;i<size;i++)
    {
        a[i]=a[i+1];
    }
    printf("\nThe updated array is: ");
    for(i=0;i<size-1;i++)
    {
        printf("%d ",a[i]);
    }
    return 0;
}
