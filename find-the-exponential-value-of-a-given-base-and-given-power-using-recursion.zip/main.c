#include <stdio.h>
int power(int base,int p)
{
    if (p==0)
    return 1;
    else
    return base*power(base,p-1);
}
int main()
{
    int base , p;
    printf("Enter the base: ");
    scanf("%d",&base);
    printf("Enter the power: ");
    scanf("%d",&p);
    printf("The exponential value is: %d ",power(base,p));
    return 0;
}

