#include<stdio.h>
#include<string.h>
int main()
{
    char name[50];
    printf("What is your name?\n");
    //scanf("%[^\n]s",name);//
    fgets(name,50,stdin);
    //printf("your name is %s",name);//
    char *ptr;
    ptr=&ptr;
    while(*ptr!='\0')
    {
        printf("%c",*ptr);
    }
    return 0;
}