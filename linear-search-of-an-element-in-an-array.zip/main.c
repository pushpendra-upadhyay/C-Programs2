#include<stdio.h>
int main()
{
    int size,i,num,position,flag=0;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("Enter the number to search: ");
    scanf("%d",&num);
    for(i=0;i<size;i++)
    {
        if(a[i]==num)
        {
            position=i+1;
            flag=1;
        }
    }
    if(flag==1)
    printf("Number found at %d position",position);
    else
    printf("Number not found");
    return 0;
}