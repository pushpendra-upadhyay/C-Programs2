#include<stdio.h>
int main()
{
    int m,n,i,j;
    printf("Enter the rows and column: ");
    scanf("%d%d",&m,&n);
    int a[m][n];
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("Enter the elements: ");
            scanf("%d",&a[i][j]);
        }
    }
    printf("The matrix created is:\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf(" %d",a[i][j]);
        }
        printf("\n");
    }
    printf("The transpose matrix is:\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf(" %d",a[j][i]);
        }
        printf("\n");
    }
    return 0;
}