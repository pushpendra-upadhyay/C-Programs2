#include <stdio.h>
int main()
{
    int size,i;
    printf("Enter size of the array : ");
    scanf("%d", &size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("\nAll negative elements in array are : ");
    for(i=0;i<size;i++)
    {
        if(a[i]<0)
        {
            printf("%d ",a[i]);
        }
    }
    return 0;
}