#include<stdio.h>
int main()
{
    int size,i,min,max;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    int a[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the elements of this array: ");
        scanf("%d",&a[i]);
    }
    for(i=0;i<size;i++)
    {
        if (min>a[i])
        min=a[i];
        if (max<a[i])
        max=a[i];
    }
    printf("maximum element of this array:%d",max);
    printf("\nminimum element of this array:%d",min);
    return 0;
}